CREATE TABLE IF NOT EXISTS nail_users (
  id TEXT PRIMARY KEY, name TEXT NOT NULL, email TEXT NOT NULL UNIQUE COLLATE NOCASE,
  password_hash TEXT NOT NULL, password_salt TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'client' CHECK (role IN ('client', 'master')),
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS nail_sessions (
  token_hash TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES nail_users(id) ON DELETE CASCADE,
  expires_at TEXT NOT NULL, created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS nail_sessions_user_idx ON nail_sessions(user_id);
CREATE INDEX IF NOT EXISTS nail_sessions_expiry_idx ON nail_sessions(expires_at);
CREATE TABLE IF NOT EXISTS nail_tickets (
  id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES nail_users(id) ON DELETE CASCADE,
  service TEXT NOT NULL, appointment_date TEXT NOT NULL, preferred_time TEXT NOT NULL DEFAULT 'Неважно',
  subject TEXT NOT NULL DEFAULT 'Запись на маникюр',
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'answered', 'confirmed', 'cancelled', 'completed')),
  created_at TEXT NOT NULL DEFAULT (datetime('now')), updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS nail_tickets_user_idx ON nail_tickets(user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS nail_tickets_status_idx ON nail_tickets(status, updated_at DESC);
CREATE TABLE IF NOT EXISTS nail_messages (
  id TEXT PRIMARY KEY, ticket_id TEXT NOT NULL REFERENCES nail_tickets(id) ON DELETE CASCADE,
  sender_id TEXT NOT NULL REFERENCES nail_users(id) ON DELETE CASCADE,
  sender_role TEXT NOT NULL CHECK (sender_role IN ('client', 'master')), body TEXT NOT NULL,
  read_by_client INTEGER NOT NULL DEFAULT 0, read_by_master INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS nail_messages_ticket_idx ON nail_messages(ticket_id, created_at ASC);
