import { createFileRoute } from "@tanstack/react-router";

const API_URL = "https://mkdlyjojjooifiodlphj.supabase.co/functions/v1/manicure-api";

function errorResponse(message: string, status: number) {
  return new Response(JSON.stringify({ error: message }), {
    status,
    headers: { "content-type": "application/json; charset=utf-8", "cache-control": "no-store" },
  });
}

async function proxy(request: Request) {
  const target = API_URL + new URL(request.url).search;
  const headers = new Headers({ accept: "application/json" });
  const cookie = request.headers.get("cookie");
  const contentType = request.headers.get("content-type");
  if (cookie) headers.set("cookie", cookie);
  if (contentType) headers.set("content-type", contentType);

  let bodyText: string | undefined;
  if (request.method !== "GET" && request.method !== "HEAD") {
    bodyText = await request.text();
    try {
      const data = JSON.parse(bodyText) as Record<string, unknown>;
      if (data.action === "trusted_master_login") return errorResponse("Недопустимый способ входа.", 400);
      const email = typeof data.email === "string" ? data.email.trim().toLowerCase() : "";
      if (data.action === "login" && email === "aleksandracareva663@gmail.com") {
        const expectedPassword = process.env.MASTER_PASSWORD;
        const internalSecret = process.env.MANICURE_INTERNAL_SECRET;
        if (!expectedPassword || !internalSecret) {
          return errorResponse("Серверный вход мастера ещё не настроен. Проверь переменные окружения проекта.", 503);
        }
        if (typeof data.password !== "string" || data.password !== expectedPassword) {
          return errorResponse("Неверная почта или пароль.", 401);
        }
        bodyText = JSON.stringify({ action: "trusted_master_login" });
        headers.set("x-manicure-internal-secret", internalSecret);
      }
    } catch {
      // Keep the upstream JSON validation and error shape for other actions.
    }
  }
  const init: RequestInit = { method: request.method, headers, cache: "no-store" };
  if (bodyText !== undefined) init.body = bodyText;
  const response = await fetch(target, init);
  const out = new Headers({
    "content-type": response.headers.get("content-type") ?? "application/json; charset=utf-8",
    "cache-control": "no-store",
  });
  const setCookie = response.headers.get("set-cookie");
  if (setCookie) out.set("set-cookie", setCookie);
  const rawBody = await response.arrayBuffer();
  let responseBody: BodyInit = rawBody;
  // The GitHub Pages client cannot read Set-Cookie, so expose the short-lived token only after a successful login.
  if (request.method === "POST" && response.ok && setCookie) {
    const match = setCookie.match(/nail_session=([^;]+)/);
    if (match?.[1]) {
      try {
        const payload = JSON.parse(new TextDecoder().decode(rawBody)) as Record<string, unknown>;
        payload.sessionToken = decodeURIComponent(match[1]);
        responseBody = JSON.stringify(payload);
      } catch {
        // Keep original response if it was not JSON.
      }
    }
  }
  return new Response(responseBody, { status: response.status, headers: out });
}

const STATIC_SITE_ORIGIN = "https://finikodel.github.io";

function withStaticCors(request: Request, response: Response) {
  const origin = request.headers.get("origin") ?? "";
  const headers = new Headers(response.headers);
  if (origin === STATIC_SITE_ORIGIN) {
    headers.set("access-control-allow-origin", STATIC_SITE_ORIGIN);
    headers.set("access-control-allow-methods", "GET, POST, OPTIONS");
    headers.set("access-control-allow-headers", "content-type");
    headers.append("vary", "Origin");
  }
  return new Response(response.body, { status: response.status, statusText: response.statusText, headers });
}

function corsPreflight(request: Request) {
  const origin = request.headers.get("origin") ?? "";
  const headers = new Headers({ "vary": "Origin" });
  if (origin === STATIC_SITE_ORIGIN) {
    headers.set("access-control-allow-origin", STATIC_SITE_ORIGIN);
    headers.set("access-control-allow-methods", "GET, POST, OPTIONS");
    headers.set("access-control-allow-headers", "content-type");
    headers.set("access-control-max-age", "86400");
  }
  return new Response(null, { status: 204, headers });
}

async function handleStaticRequest(request: Request) {
  if (request.method === "OPTIONS") return corsPreflight(request);
  return withStaticCors(request, await proxy(request));
}

export const Route = createFileRoute("/api")({
  server: { handlers: {
    GET: ({ request }) => handleStaticRequest(request),
    POST: ({ request }) => handleStaticRequest(request),
    OPTIONS: ({ request }) => handleStaticRequest(request),
  } },
});
