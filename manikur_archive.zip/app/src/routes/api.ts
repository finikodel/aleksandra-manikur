import { createFileRoute } from "@tanstack/react-router";

const API_URL = "https://mkdlyjojjooifiodlphj.supabase.co/functions/v1/manicure-api";

function errorResponse(message: string, status: number) {
  return new Response(JSON.stringify({ error: message }), {
    status,
    headers: { "content-type": "application/json; charset=utf-8", "cache-control": "no-store" },
  });
}

async function proxy(request: Request) {
  const target = API_URL + new URL(request.url).search;
  const headers = new Headers({ accept: "application/json" });
  const cookie = request.headers.get("cookie");
  const contentType = request.headers.get("content-type");
  if (cookie) headers.set("cookie", cookie);
  if (contentType) headers.set("content-type", contentType);

  let bodyText: string | undefined;
  if (request.method !== "GET" && request.method !== "HEAD") {
    bodyText = await request.text();
    try {
      const data = JSON.parse(bodyText) as Record<string, unknown>;
      if (data.action === "trusted_master_login") return errorResponse("Недопустимый способ входа.", 400);
      const email = typeof data.email === "string" ? data.email.trim().toLowerCase() : "";
      if (data.action === "login" && email === "aleksandracareva663@gmail.com") {
        const expectedPassword = process.env.MASTER_PASSWORD;
        const internalSecret = process.env.MANICURE_INTERNAL_SECRET;
        if (!expectedPassword || !internalSecret) {
          return errorResponse("Серверный вход мастера ещё не настроен. Проверь переменные окружения проекта.", 503);
        }
        if (typeof data.password !== "string" || data.password !== expectedPassword) {
          return errorResponse("Неверная почта или пароль.", 401);
        }
        bodyText = JSON.stringify({ action: "trusted_master_login" });
        headers.set("x-manicure-internal-secret", internalSecret);
      }
    } catch {
      // Keep the upstream JSON validation and error shape for other actions.
    }
  }
  const init: RequestInit = { method: request.method, headers, cache: "no-store" };
  if (bodyText !== undefined) init.body = bodyText;
  const response = await fetch(target, init);
  const out = new Headers({
    "content-type": response.headers.get("content-type") ?? "application/json; charset=utf-8",
    "cache-control": "no-store",
  });
  const setCookie = response.headers.get("set-cookie");
  if (setCookie) out.set("set-cookie", setCookie);
  return new Response(await response.arrayBuffer(), { status: response.status, headers: out });
}

export const Route = createFileRoute("/api")({
  server: { handlers: { GET: ({ request }) => proxy(request), POST: ({ request }) => proxy(request) } },
});
