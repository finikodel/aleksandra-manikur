import { useEffect, useState, type FormEvent } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { ScrollScrub } from "@/components/scroll-scrub/scroll-scrub";
import { scrollScrubScenes, scrollScrubTheme } from "@/scroll-scrub-scenes";
import { apiGet, apiPost, type StudioUser } from "@/lib/nail-studio-client";
import { ArrowUpRight, CalendarCheck, CalendarDays, CheckCircle2, Clock3, FileCheck2, Flower2, Footprints, Hand, Heart, LockKeyhole, LogIn, Mail, MapPin, Menu, MessageCircle, MessagesSquare, Palette, ShieldCheck, Sparkles, UserPlus, UserRound, X } from "lucide-react";

export const Route = createFileRoute("/")({ component: HomePage });
const serviceGroups = [
  { title: "Наращивание ногтей", icon: Hand, items: [
    { name: "Коррекция наращивания", price: "1 100 ₽" },
    { name: "mini (1–3)", price: "1 350 ₽" },
    { name: "medium (4–6)", price: "1 500 ₽" },
    { name: "mega (7–10)", price: "1 700 ₽" },
    { name: "Снятие без наращивания", price: "350 ₽" },
  ]},
  { title: "Покрытие на свои ногти", icon: Flower2, items: [
    { name: "На свои ногти (с укреплением)", price: "1 150 ₽" },
    { name: "Снятие без покрытия", price: "250 ₽" },
  ]},
  { title: "Комбинированный маникюр", icon: Hand, items: [
    { name: "Маникюр без покрытия", price: "500 ₽" },
  ]},
  { title: "Педикюр", icon: Footprints, items: [
    { name: "С покрытием + обработка стоп", price: "1 750 ₽" },
    { name: "С покрытием", price: "1 500 ₽" },
    { name: "Без покрытия", price: "900 ₽" },
    { name: "Без покрытия с обработкой стоп", price: "1 150 ₽" },
  ]},
  { title: "Японский маникюр", icon: Sparkles, items: [
    { name: "Японский маникюр", price: "700 ₽" },
  ]},
  { title: "Дополнительные услуги", icon: Palette, items: [
    { name: "Спа для ног", price: "300 ₽" },
    { name: "Спа для рук", price: "200 ₽" },
    { name: "Снятие покрытия предыдущего мастера", price: "+100 ₽" },
    { name: "Дизайн ногтей", price: "Рассчитывается отдельно" },
  ]},
];
const services = serviceGroups.flatMap((group) => group.items.map((item) => ({ ...item, category: group.title })));


function BookingForm() {
 const [busy,setBusy]=useState(false);const [error,setError]=useState("");const [created,setCreated]=useState("");const [service,setService]=useState(services[0].name);const [user,setUser]=useState<StudioUser|null>(null);const minDate=new Date().toISOString().slice(0,10);
 async function refreshUser(){try{const result=await apiGet<{user:StudioUser|null}>("me");setUser(result.user);}catch{setUser(null);}}
 useEffect(()=>{void refreshUser();const onAuth=()=>{void refreshUser();};window.addEventListener("nail-auth-changed",onAuth);return()=>window.removeEventListener("nail-auth-changed",onAuth);},[]);
 async function submit(event:FormEvent<HTMLFormElement>){event.preventDefault();if(!user){window.dispatchEvent(new Event("nail-open-auth"));return;}setError("");setCreated("");setBusy(true);const formElement=event.currentTarget;const form=new FormData(formElement);try{const result=await apiPost<{ticketId:string}>({action:"create_ticket",service,date:form.get("date"),time:form.get("time"),subject:form.get("subject"),message:form.get("message")});setCreated(result.ticketId);formElement.reset();setService(services[0].name);}catch(err){setError((err as Error).message||"Не удалось отправить заявку. Войди в аккаунт и попробуй ещё раз.");await refreshUser();}finally{setBusy(false);}}
 if(!user)return <div className="booking-form booking-gated"><span className="glass-icon large"><LockKeyhole size={22}/></span><p className="eyebrow">Личная запись</p><h3>Запись — только в аккаунте</h3><p>Создай аккаунт или войди по своей почте и паролю. Заявка, статус и переписка с мастером будут храниться в одном месте.</p><button type="button" className="button button-primary" onClick={()=>window.dispatchEvent(new Event("nail-open-auth"))}>Войти или зарегистрироваться <ArrowUpRight size={17}/></button></div>;
 return <form className="booking-form" onSubmit={submit}>{created?<div className="success-panel" role="status"><span className="success-icon"><CheckCircle2 size={25}/></span><p className="eyebrow">Заявка сохранена</p><h3>Твой тикет создан</h3><p>Номер заявки: <strong>{created}</strong>. Возвращайся в свои записи, чтобы следить за статусом и переписываться с мастером.</p><Link className="button button-primary" to="/tickets">Открыть тикет <ArrowUpRight size={17}/></Link></div>:<>
 <div className="booking-account-chip"><span className="glass-icon"><UserRound size={16}/></span><span><strong>{user.name}</strong><small>{user.email}</small></span><span className="account-verified"><ShieldCheck size={15}/> аккаунт</span></div>
 <div className="form-intro"><p className="eyebrow"><CalendarDays size={13}/> Запись онлайн</p><h3>Начнём с даты</h3><p>Выбери услугу и время — заявка сразу появится в твоих личных тикетах.</p></div>
 <div className="form-grid"><label className="field-full">Услуга<select name="service" value={service} onChange={(e)=>setService(e.target.value)}>{services.map((item)=><option key={item.name} value={item.name}>{item.name} — {item.price}</option>)}<option value="Помочь выбрать">Помочь выбрать</option></select></label><label><span className="field-label-icon"><CalendarDays size={14}/> Желаемая дата</span><input name="date" type="date" min={minDate} required/></label><label><span className="field-label-icon"><Clock3 size={14}/> Удобное время</span><select name="time" defaultValue="Неважно"><option>Неважно</option><option>Утро</option><option>День</option><option>Вечер</option></select></label><label className="field-full">Тема обращения<input name="subject" defaultValue="Запись на маникюр" maxLength={120}/></label><label className="field-full">Сообщение мастеру<textarea name="message" rows={3} maxLength={1500} placeholder="Например, желаемая длина, цвет или вопросы…"/></label></div>
 {error&&<p className="form-error" role="alert">{error}</p>}<button className="button button-primary booking-submit" type="submit" disabled={busy}>{busy?"Сохраняем заявку…":"Отправить заявку"}<ArrowUpRight size={17}/></button><p className="form-note"><ShieldCheck size={14}/> Заявка не означает автоматическое подтверждение даты. Мастер ответит в твоём тикете.</p><p className="form-login">Хочешь проверить прошлые заявки? <Link to="/tickets">Мои записи <ArrowUpRight size={14}/></Link></p>
 </>}</form>;
}

function WelcomeAuthModal() {
 const [open,setOpen]=useState(true);const [mode,setMode]=useState<"register"|"login"|"master">("register");const [busy,setBusy]=useState(false);const [checking,setChecking]=useState(true);const [error,setError]=useState("");
 useEffect(()=>{let live=true;apiGet<{user:StudioUser|null}>("me").then(({user})=>{if(live)setOpen(!user);}).catch(()=>{if(live)setOpen(true);}).finally(()=>{if(live)setChecking(false);});const openGate=()=>{setMode("register");setError("");setOpen(true);};window.addEventListener("nail-open-auth",openGate);return()=>{live=false;window.removeEventListener("nail-open-auth",openGate);};},[]);
 function authenticated(){setOpen(false);window.dispatchEvent(new Event("nail-auth-changed"));}
 async function submit(event:FormEvent<HTMLFormElement>){event.preventDefault();setBusy(true);setError("");const form=new FormData(event.currentTarget);const email=mode==="master"?"aleksandracareva663@gmail.com":String(form.get("email")??"").trim().toLowerCase();const password=String(form.get("password")??"");try{if(mode==="register")await apiPost({action:"register",name:form.get("name"),email,password});else await apiPost({action:"login",email,password});authenticated();}catch(e){const problem=e as Error&{code?:string};setError(problem.message||(mode==="login"?"Проверь почту и пароль.":"Не удалось создать аккаунт."));if(problem.code==="EMAIL_EXISTS"&&mode==="register")setMode("login");}finally{setBusy(false);}}
 if(checking||!open)return null;
 return <div className="welcome-overlay" role="presentation"><section className="welcome-modal" role="dialog" aria-modal="true" aria-labelledby="welcome-title"><div className="welcome-light welcome-light-one"/><div className="welcome-light welcome-light-two"/><div className="welcome-modal-content"><span className="welcome-mark"><Sparkles size={23}/></span><p className="eyebrow auth-eyebrow">Александра · маникюр</p><h2 id="welcome-title">Твоя красота —<br/><em>в твоём ритме</em></h2><p className="welcome-description">Войди в личный кабинет или создай аккаунт, чтобы отправлять заявки и общаться с мастером.</p><div className="auth-switch" role="tablist" aria-label="Тип входа"><button type="button" role="tab" aria-selected={mode==="register"} className={mode==="register"?"active":""} onClick={()=>{setMode("register");setError("");}}><UserPlus size={16}/> Регистрация</button><button type="button" role="tab" aria-selected={mode==="login"} className={mode==="login"?"active":""} onClick={()=>{setMode("login");setError("");}}><LogIn size={16}/> Вход</button></div><form className="auth-form welcome-login-form" onSubmit={submit}>{mode==="register"&&<label><span className="field-label-icon"><UserRound size={14}/> Твоё имя</span><input type="text" name="name" autoComplete="name" placeholder="Как к тебе обращаться" minLength={2} maxLength={80} required/></label>}<label><span className="field-label-icon"><Mail size={14}/> Электронная почта</span><input type="email" name="email" autoComplete="email" placeholder="you@example.com" value={mode==="master"?"aleksandracareva663@gmail.com":undefined} readOnly={mode==="master"} required maxLength={254}/></label><label><span className="field-label-icon"><LockKeyhole size={14}/> Пароль</span><input type="password" name="password" autoComplete={mode==="register"?"new-password":"current-password"} placeholder={mode==="register"?"Не менее 8 символов":"Твой пароль"} minLength={mode==="register"?8:undefined} maxLength={256} required/></label>{error&&<p className="form-error auth-form-error" role="alert">{error}</p>}<button className="button button-primary auth-submit" type="submit" disabled={busy}>{busy?(mode==="register"?"Создаём аккаунт…":"Входим…"):(mode==="register"?"Создать аккаунт":mode==="master"?"Войти как мастер":"Войти в аккаунт")}<ArrowUpRight size={17}/></button></form><button type="button" className="master-login-link" onClick={()=>{setMode(mode==="master"?"login":"master");setError("");}}><ShieldCheck size={14}/>{mode==="master"?"Назад к обычному входу":"Вход для мастера"}</button><p className="auth-footnote"><ShieldCheck size={14}/> Личные записи и переписка доступны после входа.</p></div></section></div>;
}

function HomePage() {
  const [mobileNavOpen, setMobileNavOpen] = useState(false);
  const closeMobileNav = () => setMobileNavOpen(false);
  return <main className="studio-page"><WelcomeAuthModal/>
    <header className="site-header">
      <Link to="/" className="brand-mark" aria-label="Александра, маникюр"><span className="brand-symbol">A</span><span><strong>Александра</strong><small>МАНИКЮР</small></span></Link>
      <nav className="desktop-nav" aria-label="Главная навигация"><a href="#services">Услуги</a><a href="#inspiration">Идеи дизайна</a><a href="#location">Адрес</a><Link to="/tickets"><UserRound size={15}/> Мои записи</Link></nav>
      <a className="vk-header-link" href="https://vk.ru/sssasha_nails_izh" target="_blank" rel="noreferrer" aria-label="Открыть сообщество ВКонтакте"><MessageCircle size={17}/><span>ВКонтакте</span><ArrowUpRight size={13}/></a>
      <a className="button button-primary header-cta" href="#booking"><CalendarDays size={16}/> Записаться <ArrowUpRight size={16}/></a>
      <button type="button" className="mobile-menu-toggle" aria-label={mobileNavOpen ? "Закрыть меню" : "Открыть меню"} aria-expanded={mobileNavOpen} aria-controls="mobile-site-nav" onClick={() => setMobileNavOpen((open) => !open)}>{mobileNavOpen ? <X size={20}/> : <Menu size={20}/>}</button>
    </header>
    {mobileNavOpen && <nav className="mobile-nav-panel" id="mobile-site-nav" aria-label="Мобильная навигация">
      <a href="#services" onClick={closeMobileNav}><Sparkles size={17}/> Услуги</a>
      <a href="#inspiration" onClick={closeMobileNav}><Palette size={17}/> Идеи дизайна</a>
      <a href="#location" onClick={closeMobileNav}><MapPin size={17}/> Адрес</a>
      <Link to="/tickets" onClick={closeMobileNav}><UserRound size={17}/> Мои записи</Link>
      <a href="https://vk.ru/sssasha_nails_izh" target="_blank" rel="noreferrer" onClick={closeMobileNav}><MessageCircle size={17}/> Сообщество ВКонтакте <ArrowUpRight size={14}/></a>
    </nav>}

    <div className="hero-shell"><ScrollScrub scenes={scrollScrubScenes} theme={scrollScrubTheme} className="studio-scrub"/><div className="hero-caption" aria-hidden="true"><span className="hero-caption-line"/><span><Sparkles size={14}/> Маникюр с вниманием к деталям</span></div><div className="hero-stamp" aria-hidden="true"><span>NAIL</span><span>CARE</span><Sparkles size={17}/></div></div>

    <section className="hero-photo-feature section" aria-label="Фото маникюра">
      <picture className="hero-photo-media">
        <source media="(max-width: 650px)" srcSet={`${import.meta.env.BASE_URL}assets/world/scene-01-mobile-poster.jpg`} />
        <img src={`${import.meta.env.BASE_URL}assets/world/scene-01-poster.jpg`} alt="Аккуратный маникюр с нежным розовым покрытием" width="1280" height="720" fetchPriority="high" decoding="async" />
      </picture>
      <div className="hero-photo-copy"><p className="eyebrow"><Sparkles size={14}/> Александра · маникюр</p><h2>Красота —<br/><em>в деталях</em></h2><p>Нежные оттенки, аккуратная форма и внимание к каждому штриху.</p><a href="https://vk.ru/sssasha_nails_izh" target="_blank" rel="noreferrer" className="button button-outline"><MessageCircle size={16}/> Смотреть сообщество <ArrowUpRight size={15}/></a></div>
    </section>

    <section className="intro-band"><p>Твоё время для себя</p><span className="intro-dot"/><p>Аккуратность в каждом движении</p><span className="intro-dot"/><p>Личная запись без лишних звонков</p></section>

    <section className="section services-section" id="services"><div className="section-heading"><div><p className="eyebrow"><Heart size={13}/> Услуги</p><h2>Найди свой <em>ритуал</em></h2></div><p className="section-lead">Не уверена, что выбрать? Оставь заявку, и мы спокойно обсудим детали в личном тикете.</p></div>
      <div className="service-groups">{serviceGroups.map((group, groupIndex)=><section className="service-group" key={group.title}><h3 className="service-group-title"><span>{String(groupIndex+1).padStart(2,"0")}</span><span className="service-title-icon"><group.icon size={15}/></span>{group.title}</h3><div className="service-list">{group.items.map((item, itemIndex)=><article className="service-row" key={item.name}><span className="service-number">{String(itemIndex+1).padStart(2,"0")}</span><div className="service-copy"><h4>{item.name}</h4></div><strong className="service-price">{item.price}</strong><a className="service-arrow" href="#booking" aria-label={`Записаться: ${item.name}`} onClick={()=>{window.setTimeout(()=>{const select=document.querySelector<HTMLSelectElement>('select[name="service"]');if(select){const setter=Object.getOwnPropertyDescriptor(HTMLSelectElement.prototype,"value")?.set;setter?.call(select,item.name);select.dispatchEvent(new Event("change",{bubbles:true}));}},0)}}>↗</a></article>)}</div></section>)}</div>
      <div className="services-footnote"><span className="footnote-flower"><Flower2 size={18}/></span><p>Дизайн рассчитывается отдельно. Снятие покрытия предыдущего мастера — дополнительно 100 ₽.</p></div>
    </section>

    <section className="inspiration-section" id="inspiration"><div className="section inspiration-head"><div><p className="eyebrow">Вдохновение</p><h2>Какое сегодня <em>настроение?</em></h2></div><p className="section-lead">Идеи для выбора оттенка. Это вдохновение, а не фотографии выполненных работ.</p></div>
      <div className="mood-grid">
        <article className="mood-card mood-soft"><div className="nail-art nail-art-soft" aria-hidden="true"><i/><i/><i/><i/><i/></div><div className="mood-meta"><span>01 / SOFT</span><h3>Нежный нюд</h3><p>Полупрозрачный розовый и мягкий блеск.</p></div></article>
        <article className="mood-card mood-classic"><div className="nail-art nail-art-classic" aria-hidden="true"><i/><i/><i/><i/><i/></div><div className="mood-meta"><span>02 / CLASSIC</span><h3>Чистая классика</h3><p>Аккуратная форма и выразительный оттенок.</p></div></article>
        <article className="mood-card mood-art"><div className="nail-art nail-art-art" aria-hidden="true"><i/><i/><i/><i/><i/></div><div className="mood-meta"><span>03 / DETAIL</span><h3>Маленький акцент</h3><p>Тонкие линии и детали, которые замечаешь не сразу.</p></div></article>
      </div>
    </section>

    <section className="booking-section section" id="booking"><div className="booking-copy"><p className="eyebrow">Твой следующий шаг</p><h2>Запишись в пару <em>касаний</em></h2><p>Выбери дату и расскажи, что хочется. После отправки появится личный тикет с номером, статусом и чатом с мастером.</p>
      <div className="booking-benefits"><div><span><FileCheck2 size={17}/></span><p><strong>Заявка сохраняется</strong><small>Можно вернуться к ней позже.</small></p></div><div><span><MessagesSquare size={17}/></span><p><strong>Переписка на сайте</strong><small>Вопросы и ответы остаются в тикете.</small></p></div><div><span><CalendarCheck size={17}/></span><p><strong>Подтверждение мастером</strong><small>Дата считается согласованной после ответа.</small></p></div></div>
    </div><BookingForm/></section>

    <section className="ticket-band"><div className="ticket-band-art" aria-hidden="true"><div className="ticket-paper"><span>МАНИКЮР · АЛЕКСАНДРА</span><strong>YOUR<br/>APPOINTMENT</strong><small>✳ TICKET Nº 001</small></div></div><div className="ticket-band-copy"><p className="eyebrow">Твоя личная зона</p><h2>Запись всегда <em>под рукой</em></h2><p>В разделе «Мои записи» можно открыть тикет, проверить статус и продолжить переписку. Для входа понадобятся почта и пароль, указанные при записи.</p><Link to="/tickets" className="button button-outline">Мои записи <span aria-hidden="true">↗</span></Link></div></section>

    <section className="location-section section" id="location"><div className="location-copy"><p className="eyebrow">Где встречаемся</p><h2>До встречи <em>на маникюре</em></h2><p>Сохрани адрес, чтобы легко найти дорогу к своему времени для себя.</p><address><MapPin size={17}/> Россия, Удмуртская Республика,<br/>Завьяловский район, село Первомайский,<br/>ул. Новая, дом 14</address><a className="button button-primary" href="https://yandex.ru/maps/?text=%D0%A0%D0%BE%D1%81%D1%81%D0%B8%D1%8F%2C%20%D0%A3%D0%B4%D0%BC%D1%83%D1%80%D1%82%D1%81%D0%BA%D0%B0%D1%8F%20%D0%A0%D0%B5%D1%81%D0%BF%D1%83%D0%B1%D0%BB%D0%B8%D0%BA%D0%B0%2C%20%D0%97%D0%B0%D0%B2%D1%8C%D1%8F%D0%BB%D0%BE%D0%B2%D1%81%D0%BA%D0%B8%D0%B9%20%D1%80%D0%B0%D0%B9%D0%BE%D0%BD%2C%20%D1%81%D0%B5%D0%BB%D0%BE%20%D0%9F%D0%B5%D1%80%D0%B2%D0%BE%D0%BC%D0%B0%D0%B9%D1%81%D0%BA%D0%B8%D0%B9%2C%20%D1%83%D0%BB%D0%B8%D1%86%D0%B0%20%D0%9D%D0%BE%D0%B2%D0%B0%D1%8F%2C%2014" target="_blank" rel="noreferrer">Открыть карту <span aria-hidden="true">↗</span></a></div>
      <div className="map-card"><iframe title="Карта: улица Новая, дом 14, село Первомайский" loading="lazy" src="https://yandex.ru/map-widget/v1/?text=%D0%A3%D0%B4%D0%BC%D1%83%D1%80%D1%82%D1%81%D0%BA%D0%B0%D1%8F%20%D0%A0%D0%B5%D1%81%D0%BF%D1%83%D0%B1%D0%BB%D0%B8%D0%BA%D0%B0%2C%20%D1%81%D0%B5%D0%BB%D0%BE%20%D0%9F%D0%B5%D1%80%D0%B2%D0%BE%D0%BC%D0%B0%D0%B9%D1%81%D0%BA%D0%B8%D0%B9%2C%20%D1%83%D0%BB%D0%B8%D1%86%D0%B0%20%D0%9D%D0%BE%D0%B2%D0%B0%D1%8F%2C%2014&z=16" referrerPolicy="no-referrer-when-downgrade"/><div className="map-caption"><span className="map-pin">⌖</span><div><strong>Александра · маникюр</strong><small>ул. Новая, 14 · Первомайский</small></div></div></div>
    </section>

    <footer className="site-footer"><Link to="/" className="brand-mark"><span className="brand-symbol">A</span><span><strong>Александра</strong><small>МАНИКЮР</small></span></Link><p>Ухоженные ногти. Спокойное время для себя.</p><div className="footer-links"><a href="mailto:aleksandracareva663@gmail.com"><Mail size={14}/> Написать мастеру</a><Link to="/tickets"><UserRound size={14}/> Мои записи</Link><Link to="/master"><ShieldCheck size={14}/> Вход мастера</Link><Link to="/privacy"><LockKeyhole size={14}/> Конфиденциальность</Link><a href="https://vk.ru/sssasha_nails_izh" target="_blank" rel="noreferrer"><MessageCircle size={14}/> ВКонтакте</a></div><small className="copyright">© {new Date().getFullYear()} Александра. Маникюр с вниманием к деталям.</small></footer>
  </main>;
}
