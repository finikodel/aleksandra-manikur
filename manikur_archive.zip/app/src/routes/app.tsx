import { createFileRoute, redirect } from "@tanstack/react-router";

// The starter's creative workspace is not part of this standalone manicure website.
export const Route = createFileRoute("/app")({
  beforeLoad: () => { throw redirect({ to: "/" }); },
  component: () => null,
});
