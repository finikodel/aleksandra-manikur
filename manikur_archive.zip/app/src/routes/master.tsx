import { useCallback, useEffect, useMemo, useState, type FormEvent } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import {
  ArrowLeft, ArrowRight, BadgeCheck, CalendarDays, CheckCircle2, Clock3,
  ClipboardList, Inbox, LayoutDashboard, LogIn, LogOut, Mail, MessageCircle,
  RefreshCw, ShieldCheck, UserRound, Users, XCircle,
} from "lucide-react";
import { apiGet, apiPost, formatDate, formatTime, STATUS_LABEL, type StudioTicket, type StudioUser } from "@/lib/nail-studio-client";

const appPath = (path: string) => `${import.meta.env.BASE_URL}${path.replace(/^\/+/, "")}`;

export const Route = createFileRoute("/master")({
  head: () => ({ meta: [{ title: "Панель мастера | Александра" }, { name: "robots", content: "noindex, nofollow" }] }),
  component: MasterPage,
});

type TicketResponse = { user: StudioUser; tickets: StudioTicket[] };
type TicketFilter = "all" | StudioTicket["status"];

const filterLabels: Record<TicketFilter, string> = {
  all: "Все",
  pending: "Новые",
  answered: "Есть ответ",
  confirmed: "Подтверждены",
  cancelled: "Отменены",
  completed: "Завершены",
};

function MasterLogin({ onLogin }: { onLogin: (email: string, password: string) => Promise<void> }) {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setBusy(true);
    setError("");
    const form = new FormData(event.currentTarget);
    try {
      await onLogin(String(form.get("email") || ""), String(form.get("password") || ""));
    } catch (problem) {
      setError((problem as Error).message || "Не удалось войти в панель.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <section className="master-login-layout">
      <div className="master-login-intro">
        <span className="master-brand-mark"><ShieldCheck size={25}/></span>
        <p className="master-kicker">ЗАКРЫТОЕ РАБОЧЕЕ ПРОСТРАНСТВО</p>
        <h1>Панель<br/><em>Александры</em></h1>
        <p>Отдельный кабинет для работы с записями: входящие заявки, расписание, статусы и сообщения клиентов — в одном месте.</p>
        <div className="master-login-points">
          <span><Inbox size={16}/> Все заявки в одном списке</span>
          <span><MessageCircle size={16}/> Переписка с клиентами</span>
          <span><CalendarDays size={16}/> Контроль дат и статусов</span>
        </div>
      </div>
      <form className="master-login-card" onSubmit={submit}>
        <div className="master-login-card-icon"><LogIn size={19}/></div>
        <p className="master-kicker">АВТОРИЗАЦИЯ</p>
        <h2>Вход мастера</h2>
        <p className="master-muted">Эта страница доступна только аккаунту владельца.</p>
        <label>Электронная почта
          <span className="master-input-wrap"><Mail size={16}/><input type="email" name="email" autoComplete="username" defaultValue="aleksandracareva663@gmail.com" required/></span>
        </label>
        <label>Пароль мастера
          <span className="master-input-wrap"><ShieldCheck size={16}/><input type="password" name="password" autoComplete="current-password" placeholder="Введите пароль мастера" required/></span>
        </label>
        {error && <p className="master-error" role="alert">{error}</p>}
        <button className="master-primary-button" type="submit" disabled={busy}>{busy ? "Проверяем доступ…" : "Войти в кабинет"}<ArrowRight size={17}/></button>
        <p className="master-login-footnote"><ShieldCheck size={14}/> Пароль мастера не совпадает с паролем от почты.</p>
      </form>
    </section>
  );
}

function MasterChat({ ticket, onChanged, onBack }: { ticket: StudioTicket; onChanged: () => Promise<void>; onBack: () => void }) {
  const [message, setMessage] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [statusBusy, setStatusBusy] = useState(false);

  async function send(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!message.trim()) return;
    setBusy(true);
    setError("");
    try {
      await apiPost({ action: "reply", ticketId: ticket.id, message: message.trim() });
      setMessage("");
      await onChanged();
    } catch (problem) {
      setError((problem as Error).message || "Не удалось отправить ответ.");
    } finally {
      setBusy(false);
    }
  }

  async function changeStatus(value: string) {
    setStatusBusy(true);
    setError("");
    try {
      await apiPost({ action: "status", ticketId: ticket.id, status: value });
      await onChanged();
    } catch (problem) {
      setError((problem as Error).message || "Не удалось изменить статус.");
    } finally {
      setStatusBusy(false);
    }
  }

  return (
    <section className="master-chat-card" id="master-ticket-detail">
      <div className="master-chat-heading">
        <button className="master-back-button" type="button" onClick={onBack}><ArrowLeft size={16}/> Все тикеты</button>
        <span className={`master-status-pill status-${ticket.status}`}>{STATUS_LABEL[ticket.status]}</span>
        <h2>{ticket.subject || "Запись на маникюр"}</h2>
        <p className="master-ticket-id">{ticket.id}</p>
      </div>
      <div className="master-client-summary">
        <span className="master-avatar"><UserRound size={19}/></span>
        <span><strong>{ticket.user_name || "Клиент"}</strong><small>{ticket.user_email || "Почта не указана"}</small></span>
        <a href={`mailto:${ticket.user_email}`} aria-label="Написать клиенту на почту"><Mail size={17}/></a>
      </div>
      <div className="master-appointment-info">
        <div><span><ClipboardList size={15}/> Услуга</span><strong>{ticket.service}</strong></div>
        <div><span><CalendarDays size={15}/> Дата</span><strong>{formatDate(ticket.appointment_date)}</strong></div>
        <div><span><Clock3 size={15}/> Время</span><strong>{ticket.preferred_time}</strong></div>
      </div>
      <label className="master-status-control">Статус записи
        <select value={ticket.status} disabled={statusBusy} onChange={(event) => void changeStatus(event.target.value)}>
          <option value="pending">Ожидает ответа</option>
          <option value="answered">Есть ответ мастера</option>
          <option value="confirmed">Запись подтверждена</option>
          <option value="cancelled">Отменена</option>
          <option value="completed">Завершена</option>
        </select>
      </label>
      <div className="master-conversation-title"><MessageCircle size={17}/><h3>Переписка с клиентом</h3><span>{ticket.messages.length}</span></div>
      <div className="master-conversation" aria-live="polite">
        {ticket.messages.length ? ticket.messages.map((item) => (
          <article key={item.id} className={`master-message ${item.sender_role === "master" ? "is-master" : "is-client"}`}>
            <p>{item.body}</p>
            <small>{item.sender_role === "master" ? "Вы · мастер" : ticket.user_name || "Клиент"} · {formatTime(item.created_at)}</small>
          </article>
        )) : <p className="master-empty-chat">Пока нет сообщений. Напишите клиенту первым.</p>}
      </div>
      <form className="master-reply-form" onSubmit={send}>
        <textarea value={message} onChange={(event) => setMessage(event.target.value)} maxLength={1500} rows={3} placeholder="Напишите ответ клиенту…" aria-label="Ответ клиенту" required/>
        <button className="master-primary-button" type="submit" disabled={busy || !message.trim()}>{busy ? "Отправляем…" : "Отправить ответ"}<ArrowRight size={16}/></button>
      </form>
      {error && <p className="master-error" role="alert">{error}</p>}
    </section>
  );
}

function MasterPage() {
  const [user, setUser] = useState<StudioUser | null>(null);
  const [tickets, setTickets] = useState<StudioTicket[]>([]);
  const [selected, setSelected] = useState("");
  const [filter, setFilter] = useState<TicketFilter>("all");
  const [mobileView, setMobileView] = useState<"list" | "detail">("list");
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState("");

  const loadTickets = useCallback(async (selectedId?: string) => {
    const data = await apiGet<TicketResponse>("tickets", selectedId ? { selected: selectedId } : undefined);
    if (data.user.role !== "master") {
      window.location.replace(appPath("tickets"));
      return;
    }
    setUser(data.user);
    setTickets(data.tickets);
    setSelected((old) => selectedId && data.tickets.some((ticket) => ticket.id === selectedId)
      ? selectedId
      : data.tickets.some((ticket) => ticket.id === old) ? old : (data.tickets[0]?.id ?? ""));
  }, []);

  useEffect(() => {
    let alive = true;
    (async () => {
      try {
        const result = await apiGet<{ user: StudioUser | null }>("me");
        if (!alive) return;
        if (result.user?.role === "master") await loadTickets();
        else if (result.user) window.location.replace(appPath("tickets"));
        else setUser(null);
      } catch (problem) {
        if (alive) setError((problem as Error).message || "Не удалось проверить вход.");
      } finally {
        if (alive) setLoading(false);
      }
    })();
    return () => { alive = false; };
  }, [loadTickets]);

  useEffect(() => {
    if (!user) return;
    const interval = window.setInterval(() => {
      if (!document.hidden) void loadTickets(selected || undefined).catch((problem) => setError((problem as Error).message));
    }, 15000);
    return () => window.clearInterval(interval);
  }, [user, selected, loadTickets]);

  async function signIn(email: string, password: string) {
    const result = await apiPost<{ user: StudioUser }>({ action: "login", email, password });
    if (result.user.role !== "master") throw new Error("Этот вход предназначен только для мастера.");
    setUser(result.user);
    await loadTickets();
  }

  async function logout() {
    try { await apiPost({ action: "logout" }); }
    finally {
      setUser(null);
      setTickets([]);
      setSelected("");
      setFilter("all");
    }
  }

  async function refresh() {
    setRefreshing(true);
    setError("");
    try { await loadTickets(selected || undefined); }
    catch (problem) { setError((problem as Error).message || "Не удалось обновить заявки."); }
    finally { setRefreshing(false); }
  }

  const counts = useMemo(() => ({
    all: tickets.length,
    pending: tickets.filter((ticket) => ticket.status === "pending").length,
    answered: tickets.filter((ticket) => ticket.status === "answered").length,
    confirmed: tickets.filter((ticket) => ticket.status === "confirmed").length,
    unread: tickets.reduce((total, ticket) => total + ticket.unread, 0),
  }), [tickets]);

  const visibleTickets = useMemo(() => filter === "all" ? tickets : tickets.filter((ticket) => ticket.status === filter), [tickets, filter]);
  const activeTicket = tickets.find((ticket) => ticket.id === selected);

  function showTickets() {
    setMobileView("list");
    document.getElementById("master-ticket-list")?.scrollIntoView({ behavior: "smooth", block: "start" });
  }

  function chooseTicket(ticketId: string) {
    setSelected(ticketId);
    setMobileView("detail");
    void loadTickets(ticketId).catch((problem) => setError((problem as Error).message));
  }

  return (
    <main className="master-app">
      <header className="master-header">
        <Link to="/master" className="master-brand"><span className="master-brand-symbol">A</span><span><strong>Александра</strong><small>РАБОЧИЙ КАБИНЕТ</small></span></Link>
        <div className="master-header-actions">
          <span className="master-private-label"><ShieldCheck size={15}/> Только для мастера</span>
          <Link className="master-header-link" to="/">На сайт <ArrowRight size={14}/></Link>
          {user && <button className="master-logout-button" onClick={() => void logout()}><LogOut size={15}/> Выйти</button>}
        </div>
      </header>

      <div className="master-main-content">
        {loading ? (
          <div className="master-loading-card"><span className="master-loading-icon"><RefreshCw size={20}/></span><h1>Открываем рабочий кабинет</h1><p>Проверяем доступ и загружаем заявки…</p></div>
        ) : !user ? (
          <MasterLogin onLogin={signIn}/>
        ) : (
          <>
            <section className="master-dashboard-hero">
              <div>
                <p className="master-kicker"><LayoutDashboard size={14}/> РАБОЧАЯ ПАНЕЛЬ</p>
                <h1>Здравствуйте, <em>Александра</em></h1>
                <p>Здесь собраны записи клиентов, их пожелания и переписка. Новые заявки автоматически появляются в списке.</p>
              </div>
              <button className="master-view-tickets-button" onClick={showTickets}><ClipboardList size={19}/><span>Просмотр тикетов</span><strong>{counts.all}</strong><ArrowRight size={16}/></button>
            </section>

            <section className="master-stats-grid" aria-label="Сводка заявок">
              <article className="master-stat-card"><span className="master-stat-icon is-new"><Inbox size={19}/></span><span className="master-stat-label">Новые заявки</span><strong>{counts.pending}</strong><small>Ожидают вашего ответа</small></article>
              <article className="master-stat-card"><span className="master-stat-icon is-answered"><MessageCircle size={19}/></span><span className="master-stat-label">В диалоге</span><strong>{counts.answered}</strong><small>Есть ответ мастера</small></article>
              <article className="master-stat-card"><span className="master-stat-icon is-confirmed"><BadgeCheck size={19}/></span><span className="master-stat-label">Подтверждено</span><strong>{counts.confirmed}</strong><small>Записи согласованы</small></article>
              <article className="master-stat-card"><span className="master-stat-icon is-total"><Users size={19}/></span><span className="master-stat-label">Всего заявок</span><strong>{counts.all}</strong><small>{counts.unread ? `${counts.unread} непрочитанных сообщений` : "Все сообщения прочитаны"}</small></article>
            </section>

            {error && <div className="master-error-banner" role="alert">{error}</div>}

            <section className={`master-workspace master-view-${mobileView}`} id="master-ticket-list">
              <div className="master-ticket-panel">
                <div className="master-ticket-panel-heading">
                  <div><p className="master-kicker"><Inbox size={14}/> ВХОДЯЩИЕ</p><h2>Заявки клиентов</h2><small>Нажмите на заявку, чтобы открыть тикет и переписку</small></div>
                  <button className="master-refresh-button" type="button" onClick={() => void refresh()} disabled={refreshing} aria-label="Обновить заявки"><RefreshCw size={16} className={refreshing ? "is-spinning" : ""}/></button>
                </div>
                <div className="master-filter-tabs" role="tablist" aria-label="Фильтр заявок">
                  {(Object.keys(filterLabels) as TicketFilter[]).map((key) => (
                    <button type="button" role="tab" aria-selected={filter === key} className={filter === key ? "is-active" : ""} key={key} onClick={() => { setFilter(key); const next = key === "all" ? tickets : tickets.filter((ticket) => ticket.status === key); if (next.length) { setSelected(next[0].id); void loadTickets(next[0].id).catch((problem) => setError((problem as Error).message)); } else setSelected(""); }}>
                      {filterLabels[key]} <span>{key === "all" ? counts.all : tickets.filter((ticket) => ticket.status === key).length}</span>
                    </button>
                  ))}
                </div>
                <div className="master-ticket-list">
                  {visibleTickets.length ? visibleTickets.map((ticket) => (
                    <button type="button" key={ticket.id} className={`master-ticket-item ${selected === ticket.id ? "is-selected" : ""}`} aria-current={selected === ticket.id ? "true" : undefined} onClick={() => chooseTicket(ticket.id)}>
                      <span className="master-ticket-item-icon"><UserRound size={17}/></span>
                      <span className="master-ticket-item-copy"><strong>{ticket.user_name || "Клиент"}</strong><small>{ticket.service}</small><small><CalendarDays size={12}/> {formatDate(ticket.appointment_date)} <span>·</span> {ticket.preferred_time}</small></span>
                      <span className="master-ticket-item-side">{ticket.unread > 0 && <b className="master-unread-badge">{ticket.unread}</b>}<span className={`master-status-dot status-${ticket.status}`} title={STATUS_LABEL[ticket.status]} />{selected === ticket.id && <ArrowRight size={15}/>}</span>
                    </button>
                  )) : <div className="master-empty-list"><span><CheckCircle2 size={22}/></span><strong>Заявок в этой категории нет</strong><small>Когда появятся новые записи, они отобразятся здесь.</small></div>}
                </div>
                <div className="master-list-footer"><span><RefreshCw size={12}/> Автообновление каждые 15 секунд</span><span>{visibleTickets.length} из {tickets.length}</span></div>
              </div>

              <div className="master-detail-panel">
                {activeTicket ? <MasterChat ticket={activeTicket} onChanged={() => loadTickets(activeTicket.id)} onBack={showTickets}/> : (
                  <div className="master-detail-empty"><span><ClipboardList size={30}/></span><h2>Выберите тикет</h2><p>Откройте заявку в списке слева, чтобы посмотреть данные клиента, выбрать статус и ответить на сообщение.</p><button type="button" className="master-primary-button" onClick={showTickets}>Просмотр тикетов <ArrowRight size={16}/></button></div>
                )}
              </div>
            </section>
          </>
        )}
      </div>
      <footer className="master-footer"><span>Александра · рабочее пространство мастера</span><Link to="/">Вернуться на сайт</Link></footer>
    </main>
  );
}
