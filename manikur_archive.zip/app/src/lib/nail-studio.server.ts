import { bindings } from "./bindings.server";

export type NailRole = "client" | "master";
export type NailUser = { id: string; name: string; email: string; role: NailRole };
export function json(data: unknown, status = 200, headers?: HeadersInit) {
  const h = new Headers(headers); h.set("content-type", "application/json; charset=utf-8"); h.set("cache-control", "no-store");
  return new Response(JSON.stringify(data), { status, headers: h });
}
export function fail(message: string, status = 400, code?: string) { return json({ error: message, ...(code ? { code } : {}) }, status); }
function bytesToHex(bytes: Uint8Array) { return Array.from(bytes, (b) => b.toString(16).padStart(2, "0")).join(""); }
function hexToBytes(hex: string) { return new Uint8Array(hex.match(/.{1,2}/g)?.map((part) => parseInt(part, 16)) ?? []); }
export function randomHex(size = 24) { const bytes = new Uint8Array(size); crypto.getRandomValues(bytes); return bytesToHex(bytes); }
export async function sha256(value: string) { const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(value)); return bytesToHex(new Uint8Array(digest)); }
export async function passwordHash(password: string, salt: string) {
  const key = await crypto.subtle.importKey("raw", new TextEncoder().encode(password), "PBKDF2", false, ["deriveBits"]);
  const bits = await crypto.subtle.deriveBits({ name: "PBKDF2", salt: hexToBytes(salt), iterations: 120_000, hash: "SHA-256" }, key, 256);
  return bytesToHex(new Uint8Array(bits));
}
export function parseCookies(request: Request) {
  const raw = request.headers.get("cookie") ?? "";
  return Object.fromEntries(raw.split(";").map((part) => part.trim()).filter(Boolean).map((part) => {
    const at = part.indexOf("="); return at < 0 ? [part, ""] : [part.slice(0, at), decodeURIComponent(part.slice(at + 1))];
  }));
}
export function sessionCookie(token: string, maxAge = 60 * 60 * 24 * 30) { return `nail_session=${encodeURIComponent(token)}; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=${maxAge}`; }
export async function currentUser(request: Request): Promise<NailUser | null> {
  const db = bindings().DB; const token = parseCookies(request).nail_session;
  if (!db || !token) return null;
  const row = await db.prepare("SELECT u.id, u.name, u.email, u.role FROM nail_sessions s JOIN nail_users u ON u.id=s.user_id WHERE s.token_hash=? AND s.expires_at>? LIMIT 1")
    .bind(await sha256(token), new Date().toISOString()).first<NailUser>();
  return row ?? null;
}
export function newId() { return crypto.randomUUID(); }
export function getDb() { return bindings().DB; }
export function getMasterPassword() { return bindings().MASTER_PASSWORD; }
export const MASTER_EMAIL = "aleksandracareva663@gmail.com";
