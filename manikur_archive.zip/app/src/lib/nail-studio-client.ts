export type StudioUser = { id: string; name: string; email: string; role: "client" | "master" };
export type StudioMessage = { id: string; ticket_id: string; sender_id: string; sender_role: "client" | "master"; body: string; created_at: string; read_by_client: number; read_by_master: number };
export type StudioTicket = { id: string; user_id: string; user_name?: string; user_email?: string; service: string; appointment_date: string; preferred_time: string; subject: string; status: "pending" | "answered" | "confirmed" | "cancelled" | "completed"; created_at: string; updated_at: string; unread: number; messages: StudioMessage[] };
export const STATUS_LABEL: Record<StudioTicket["status"], string> = { pending: "Ожидает ответа", answered: "Есть ответ мастера", confirmed: "Запись подтверждена", cancelled: "Запись отменена", completed: "Завершена" };

// GitHub Pages is static, so client requests go directly to the Supabase Edge Function.
// The master password is checked only by the Vercel endpoint and is never sent to Supabase.
const CLIENT_API_URL = "https://mkdlyjojjooifiodlphj.supabase.co/functions/v1/manicure-static-api";
const MASTER_API_URL = "https://aleksandra-manikur.vercel.app/api";
const MASTER_LOGIN_EMAIL = "aleksandracareva663@gmail.com";
const SESSION_STORAGE_KEY = "nail_studio_session_token";

type ApiError = Error & { code?: string };

function getSessionToken(): string {
  if (typeof window === "undefined") return "";
  try { return window.sessionStorage.getItem(SESSION_STORAGE_KEY) ?? ""; }
  catch { return ""; }
}

function storeSessionToken(token: unknown): void {
  if (typeof window === "undefined" || typeof token !== "string" || !token) return;
  try { window.sessionStorage.setItem(SESSION_STORAGE_KEY, token); }
  catch { /* Session storage may be unavailable in a restricted browser context. */ }
}

function clearSessionToken(): void {
  if (typeof window === "undefined") return;
  try { window.sessionStorage.removeItem(SESSION_STORAGE_KEY); }
  catch { /* Ignore storage cleanup failures; the server session still expires. */ }
}

async function readJson<T>(response: Response): Promise<T & { error?: string; code?: string; sessionToken?: string }> {
  const raw = await response.text();
  let data: (T & { error?: string; code?: string; sessionToken?: string });
  try {
    data = JSON.parse(raw) as T & { error?: string; code?: string; sessionToken?: string };
  } catch {
    throw new Error(`Сервер вернул не JSON (HTTP ${response.status}). Проверьте подключение и попробуйте ещё раз.`);
  }
  if (!response.ok) {
    const error = new Error(data.error || "Не удалось выполнить действие.") as ApiError;
    error.code = data.code;
    throw error;
  }
  return data;
}

function makeHeaders(includeJson = false, includeAuth = true): Headers {
  const headers = new Headers({ accept: "application/json" });
  if (includeJson) headers.set("content-type", "application/json");
  const token = includeAuth ? getSessionToken() : "";
  if (token) headers.set("authorization", `Bearer ${token}`);
  return headers;
}

export async function apiGet<T>(action: string, extra?: Record<string, string>): Promise<T> {
  const params = new URLSearchParams({ action, ...(extra ?? {}) });
  const response = await fetch(`${CLIENT_API_URL}?${params.toString()}`, {
    method: "GET",
    mode: "cors",
    credentials: "omit",
    cache: "no-store",
    headers: makeHeaders(),
  });
  return await readJson<T>(response);
}

export async function apiPost<T>(body: Record<string, unknown>): Promise<T> {
  const isMasterLogin = body.action === "login"
    && typeof body.email === "string"
    && body.email.trim().toLowerCase() === MASTER_LOGIN_EMAIL;
  const target = isMasterLogin ? MASTER_API_URL : CLIENT_API_URL;
  const response = await fetch(target, {
    method: "POST",
    mode: "cors",
    credentials: "omit",
    cache: "no-store",
    headers: makeHeaders(true, !isMasterLogin),
    body: JSON.stringify(body),
  });
  const data = await readJson<T>(response);
  if (body.action === "logout") clearSessionToken();
  else if (data.sessionToken) storeSessionToken(data.sessionToken);
  return data;
}

export function formatDate(value: string) { return new Intl.DateTimeFormat("ru-RU", { day: "numeric", month: "long", year: "numeric" }).format(new Date(`${value}T12:00:00`)); }
export function formatTime(value: string) { try { return new Intl.DateTimeFormat("ru-RU", { hour: "2-digit", minute: "2-digit" }).format(new Date(value)); } catch { return value; } }
