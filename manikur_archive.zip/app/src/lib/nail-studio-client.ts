export type StudioUser = { id: string; name: string; email: string; role: "client" | "master" };
export type StudioMessage = { id: string; ticket_id: string; sender_id: string; sender_role: "client" | "master"; body: string; created_at: string; read_by_client: number; read_by_master: number };
export type StudioTicket = { id: string; user_id: string; user_name?: string; user_email?: string; service: string; appointment_date: string; preferred_time: string; subject: string; status: "pending" | "answered" | "confirmed" | "cancelled" | "completed"; created_at: string; updated_at: string; unread: number; messages: StudioMessage[] };
export const STATUS_LABEL: Record<StudioTicket["status"], string> = { pending: "Ожидает ответа", answered: "Есть ответ мастера", confirmed: "Запись подтверждена", cancelled: "Запись отменена", completed: "Завершена" };
export async function apiGet<T>(action: string, extra?: Record<string, string>): Promise<T> {
  const params = new URLSearchParams({ action, ...(extra ?? {}) });
  const response = await fetch(`/api?${params.toString()}`, { credentials: "same-origin", headers: { accept: "application/json" } });
  const data = await response.json() as T & { error?: string };
  if (!response.ok) throw new Error(data.error || "Не удалось загрузить данные.");
  return data;
}
export async function apiPost<T>(body: Record<string, unknown>): Promise<T> {
  const response = await fetch("/api", { method: "POST", credentials: "same-origin", headers: { "content-type": "application/json", accept: "application/json" }, body: JSON.stringify(body) });
  const data = await response.json() as T & { error?: string; code?: string };
  if (!response.ok) { const error = new Error(data.error || "Не удалось выполнить действие.") as Error & { code?: string }; error.code = data.code; throw error; }
  return data;
}
export function formatDate(value: string) { return new Intl.DateTimeFormat("ru-RU", { day: "numeric", month: "long", year: "numeric" }).format(new Date(`${value}T12:00:00`)); }
export function formatTime(value: string) { try { return new Intl.DateTimeFormat("ru-RU", { hour: "2-digit", minute: "2-digit" }).format(new Date(value)); } catch { return value; } }
