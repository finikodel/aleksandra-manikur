import type { ScrollScrubScene, ScrollScrubTheme } from "@/components/scroll-scrub/scroll-scrub";

export const scrollScrubTheme: ScrollScrubTheme = {
  accent: "#9B365A",
  background: "#FFF9F8",
  ink: "#30212A",
  muted: "#765E69",
};

export const scrollScrubScenes: ScrollScrubScene[] = [
  {
    body: "Аккуратный маникюр, спокойная атмосфера и внимание к тому, что важно именно тебе.",
    clip: "/assets/world/scene-01.mp4",
    id: "manicure-intro",
    kicker: "АЛЕКСАНДРА · МАНИКЮР",
    label: "Знакомство",
    mobileClip: "/assets/world/scene-01-mobile.mp4",
    mobilePoster: "/assets/world/scene-01-mobile-poster.jpg",
    poster: "/assets/world/scene-01-poster.jpg",
    tags: ["Запись онлайн", "Личный тикет", "Переписка с мастером"],
    title: "Красота в деталях",
    scroll: 1.5,
    align: "left",
  },
];
