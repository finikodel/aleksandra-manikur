import type { ScrollScrubScene, ScrollScrubTheme } from "@/components/scroll-scrub/scroll-scrub";

export const scrollScrubTheme: ScrollScrubTheme = {
  accent: "#9B365A",
  background: "#FFF9F8",
  ink: "#30212A",
  muted: "#765E69",
};

const publicAsset = (path: string) => `${import.meta.env.BASE_URL}${path}`;

export const scrollScrubScenes: ScrollScrubScene[] = [
  {
    body: "Аккуратный маникюр, спокойная атмосфера и внимание к тому, что важно именно тебе.",
    clip: publicAsset("assets/world/scene-01.mp4"),
    id: "manicure-intro",
    kicker: "АЛЕКСАНДРА · МАНИКЮР",
    label: "Знакомство",
    mobileClip: publicAsset("assets/world/scene-01-mobile.mp4"),
    mobilePoster: publicAsset("assets/world/scene-01-mobile-poster.jpg"),
    poster: publicAsset("assets/world/scene-01-poster.jpg"),
    tags: ["Запись онлайн", "Личный тикет", "Переписка с мастером"],
    title: "Красота в деталях",
    scroll: 1.5,
    align: "left",
  },
];
