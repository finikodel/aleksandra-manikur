# Aleksandra | Маникюр — Render Free

## Подготовлено
- `Dockerfile` builds the existing TanStack Start app with Nitro's `node-server` preset.
- `render.yaml` asks Render to create a Docker web service on the Free plan, health-checking `/`.
- No `.env` file, password, API key, or server secret is included in this archive.

## Important: repository needed
Render deploys application source from a Git repository (or a public Git repository URL) when building from source. Upload this project to a Git provider repository, then in Render choose **New → Web Service**, select the repository, keep `Docker` as the runtime, and choose **Free**. The `render.yaml` may be used as a Blueprint if you prefer.

## Configure the master's secure login
The Render service needs two environment variables set in **Render → service → Environment**: `MASTER_PASSWORD` and `MANICURE_INTERNAL_SECRET`. Do not commit either value to GitHub. `MASTER_PASSWORD` is the existing master login password. `MANICURE_INTERNAL_SECRET` must match the server secret currently expected by the Supabase Edge Function; if that secret is rotated, update the hash in the Supabase function at the same time.

The website's normal client login and booking API continues to use the existing Supabase project. After deployment, test the home page, register/login, and a test booking.

## Free plan limitations
Render's Free Web Services sleep after 15 minutes without incoming traffic; the next request can take about a minute to wake up. Render's free service filesystem is ephemeral; this site stores booking data in Supabase, not local files. Check current plan and usage limits in Render before creating the service.
