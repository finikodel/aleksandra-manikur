# Aleksandra Nail Studio: design brief

## Design read
A friendly manicure studio for local clients in Pervomaysky, Udmurtia; calm, feminine, clear, and welcoming without luxury clichés.

## Concept spine
**The finishing touch.** The page moves from a soft manicure close-up toward a glossy nail surface. Each section uses curved nail-like edges, fine silver lines, and petal geometry.

## Delivery tier
Cinema. The hero is a user-controlled scroll-scrub journey, followed by a direct booking and ticket workflow.

## Animation mode: animated-website

## Journey block
- **Journey shape:** single-shot. One continuous camera push-in across one manicure illustration is more coherent than stitched scenes for a local service.
- **Journey:** establish the blush studio and clean tools with “Красота в деталях”; travel closer toward the manicure with “Аккуратно. Спокойно. С вниманием к деталям”; finish on glossy highlights with “Твой следующий маникюр начинается с записи”. The film has no baked-in text.
- **World grammar:** authored editorial illustration, pale rose and porcelain, berry accent, soft daylight, silver highlights, one right-of-center hand silhouette.
- **Mobile framing:** vertical crop centers the manicure hand; copy anchors low-left with a porcelain veil.
- **Delivery budget:** desktop and mobile MP4s each remain under 1 MiB.

## Locked palette
- Porcelain `#FFF9F8` and blush `#E8B1C1` surfaces.
- Berry rose `#9B365A` is the single accent for actions and important states.
- Ink `#30212A`, muted plum `#7C6570`, silver `#E7DCE1`.
- Derived from manicure polish and soft daylight, not a generic beige-and-brass luxury template.

## Locked type
Outfit for display and body, with a compact IBM Plex Mono eyebrow for functional labels. No serif display treatment.

## Section plan
1. Scroll-scrub hero: full-bleed illustration, headline and persistent booking CTA.
2. Service menu: asymmetric editorial rows, no invented prices.
3. Style inspiration: three illustrated nail moods, clearly labelled inspiration rather than actual portfolio photos.
4. Booking: framed form with account creation so tickets can be revisited.
5. Ticket explainer: ticket-stub motif.
6. Location: address and map.
7. Footer: contact email and private ticket entry.

## Asset plan
Main manicure illustration and exact-frame desktop/mobile posters plus scroll-scrub MP4s; custom nail-style illustrations and repeating petal texture; monogram favicon and social card. Original authored artwork, no stock imagery or fake testimonials.

## CTA inventory
Header compact berry “Записаться”; service rows “Выбрать услугу”; booking solid “Отправить заявку”; ticket framed “Мои записи”; location outlined “Открыть карту”.

## Interaction and accessibility
Booking creates a persistent D1 ticket and a client account. Clients can sign in later to view status and chat. Master dashboard is server-authorized using the `MASTER_PASSWORD` secret. Motion respects `prefers-reduced-motion`; forms have explicit states; passwords are hashed server-side; sessions use HttpOnly cookies.
