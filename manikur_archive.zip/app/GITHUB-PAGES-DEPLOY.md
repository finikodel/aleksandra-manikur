# GitHub Pages для «Александра | Маникюр»

Этот код рассчитан на адрес https://finikodel.github.io/aleksandra-manikur/ . GitHub Pages обслуживает статические файлы; заявки, регистрация и клиентские сессии используют отдельную Supabase Edge Function `manicure-static-api`. Вход мастера проходит через защищённый серверный маршрут Vercel только на этапе проверки пароля; пароль и внутренние секреты не включены в этот архив.

В репозитории должны лежать `manikur_archive.zip` и файл workflow `.github/workflows/deploy.yml`. Workflow распаковывает этот архив, запускает `bun install --frozen-lockfile`, `bun run build`, копирует `._shell.html` в `index.html` и `404.html`, затем публикует `app/.output/public` через GitHub Pages. В Settings → Pages нужно выбрать GitHub Actions как источник.

Если вход мастера не проходит, проверьте, что API `https://aleksandra-manikur.vercel.app/api` доступен из сети браузера, так как секрет мастера намеренно не хранится в публичном статическом коде.
