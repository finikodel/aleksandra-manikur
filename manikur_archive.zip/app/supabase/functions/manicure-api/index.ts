import { createClient } from "npm:@supabase/supabase-js@2";
const db = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!, { auth: { persistSession: false, autoRefreshToken: false } });
const MASTER_EMAIL = "aleksandracareva663@gmail.com", MASTER_NAME = "Александра";
const SERVICES = new Set(["Коррекция наращивания", "mini (1–3)", "medium (4–6)", "mega (7–10)", "Снятие без наращивания", "На свои ногти (с укреплением)", "Снятие без покрытия", "Маникюр без покрытия", "С покрытием + обработка стоп", "С покрытием", "Без покрытия", "Без покрытия с обработкой стоп", "Японский маникюр", "Спа для ног", "Спа для рук", "Снятие покрытия предыдущего мастера", "Дизайн ногтей", "Помочь выбрать"]);
const STATUSES = new Set(["pending", "confirmed", "cancelled", "completed"]);
const emailOf = (v: unknown) => typeof v === "string" ? v.trim().toLowerCase().slice(0, 254) : "";
const textOf = (v: unknown, max = 1500) => typeof v === "string" ? v.trim().slice(0, max) : "";
const validEmail = (v: string) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v);
const bytesHex = (b: Uint8Array) => Array.from(b, (v) => v.toString(16).padStart(2, "0")).join("");
const hexBytes = (s: string) => new Uint8Array(s.match(/.{1,2}/g)?.map((v) => parseInt(v, 16)) ?? []);
function randomHex(size = 32) { const b = new Uint8Array(size); crypto.getRandomValues(b); return bytesHex(b); }
async function sha256(v: string) { return bytesHex(new Uint8Array(await crypto.subtle.digest("SHA-256", new TextEncoder().encode(v)))); }
async function passwordHash(password: string, salt: string) {
 const k = await crypto.subtle.importKey("raw", new TextEncoder().encode(password), "PBKDF2", false, ["deriveBits"]);
 const bits = await crypto.subtle.deriveBits({ name: "PBKDF2", salt: hexBytes(salt), iterations: 120000, hash: "SHA-256" }, k, 256);
 return bytesHex(new Uint8Array(bits));
}
function json(data: unknown, status = 200, headers?: HeadersInit) { const h = new Headers(headers); h.set("content-type", "application/json; charset=utf-8"); h.set("cache-control", "no-store"); return new Response(JSON.stringify(data), { status, headers: h }); }
function fail(message: string, status = 400, code?: string) { return json({ error: message, ...(code ? { code } : {}) }, status); }
function sessionCookie(token: string, maxAge = 2592000) { return `nail_session=${encodeURIComponent(token)}; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=${maxAge}`; }
function cookieToken(request: Request) { const c = (request.headers.get("cookie") ?? "").split(";").map((s) => s.trim()).find((s) => s.startsWith("nail_session=")); if (!c) return ""; try { return decodeURIComponent(c.slice(13)); } catch { return ""; } }
async function bodyOf(request: Request): Promise<Record<string, unknown>> { try { const v = await request.json(); return v && typeof v === "object" ? v as Record<string, unknown> : {}; } catch { return {}; } }
async function currentUser(request: Request) {
 const token = cookieToken(request); if (!token) return null;
 const { data: s } = await db.from("nail_sessions").select("user_id").eq("token_hash", await sha256(token)).gt("expires_at", new Date().toISOString()).maybeSingle();
 if (!s?.user_id) return null;
 const { data: u } = await db.from("nail_users").select("id,name,email,role").eq("id", s.user_id).maybeSingle(); return u ?? null;
}
async function createSession(userId: string) { const token = randomHex(32); const { error } = await db.from("nail_sessions").insert({ token_hash: await sha256(token), user_id: userId, expires_at: new Date(Date.now() + 2592000000).toISOString() }); if (error) throw error; return token; }
const MASTER_PASSWORD_SALT = "9ee4d4cd0f77c04297db20dcbaed4a89";
const MASTER_PASSWORD_HASH = "7d8ad9976c2ef84223b3e0239109adc9a85184fc1e10db621d95faec3d4d6dff";
async function login(data: Record<string, unknown>) {
 const email = emailOf(data.email), password = textOf(data.password, 256);
 if (!validEmail(email) || !password) return fail("Введите корректную почту и пароль.");
 if (email === MASTER_EMAIL) {
  if (await passwordHash(password, MASTER_PASSWORD_SALT) !== MASTER_PASSWORD_HASH) return fail("Неверная почта или пароль.", 401);
  let { data: master, error: findError } = await db.from("nail_users").select("id,name,email,role,password_hash,password_salt").eq("email", MASTER_EMAIL).maybeSingle();
  if (findError) { console.error(findError); return fail("Не удалось проверить аккаунт мастера.", 500); }
  if (!master) {
   const { data: created, error: insertError } = await db.from("nail_users").insert({ id: crypto.randomUUID(), name: MASTER_NAME, email: MASTER_EMAIL, role: "master", password_hash: MASTER_PASSWORD_HASH, password_salt: MASTER_PASSWORD_SALT, created_at: new Date().toISOString() }).select("id,name,email,role,password_hash,password_salt").single();
   master = created;
   if (insertError) {
    const retry = await db.from("nail_users").select("id,name,email,role,password_hash,password_salt").eq("email", MASTER_EMAIL).maybeSingle();
    if (retry.error || !retry.data) { console.error(insertError, retry.error); return fail("Не удалось создать аккаунт мастера.", 500); }
    master = retry.data;
   }
  }
  const { error: normalizeError } = await db.from("nail_users").update({ name: MASTER_NAME, role: "master", password_hash: MASTER_PASSWORD_HASH, password_salt: MASTER_PASSWORD_SALT }).eq("id", master.id);
  if (normalizeError) { console.error(normalizeError); return fail("Не удалось настроить аккаунт мастера.", 500); }
  const token = await createSession(master.id);
  return json({ user: { id: master.id, name: MASTER_NAME, email: MASTER_EMAIL, role: "master" } }, 200, { "set-cookie": sessionCookie(token) });
 }
 const { data: u, error } = await db.from("nail_users").select("id,name,email,role,password_hash,password_salt").eq("email", email).maybeSingle();
 if (error) { console.error(error); return fail("Не удалось проверить аккаунт. Попробуйте позже.", 500); }
 if (!u || u.role !== "client") return fail("Неверная почта или пароль.", 401);
 if (await passwordHash(password, u.password_salt) !== u.password_hash) return fail("Неверная почта или пароль.", 401);
 const token = await createSession(u.id);
 return json({ user: { id: u.id, name: u.name, email: u.email, role: u.role } }, 200, { "set-cookie": sessionCookie(token) });
}
async function oauthLogin(data: Record<string, unknown>) {
 const accessToken = textOf(data.access_token, 8192);
 if (!accessToken) return fail("Не получен токен OAuth.", 401);
 const { data: authResult, error: authError } = await db.auth.getUser(accessToken);
 if (authError || !authResult.user?.email) { console.error(authError); return fail("Провайдер не подтвердил аккаунт.", 401); }
 const authUser = authResult.user, email = emailOf(authUser.email);
 if (!validEmail(email)) return fail("Провайдер не вернул корректную почту.", 401);
 if (email === MASTER_EMAIL) return fail("Для этой почты используй отдельную кнопку «Вход для мастера».", 403);
 let { data: user, error: findError } = await db.from("nail_users").select("id,name,email,role").eq("email", email).maybeSingle();
 if (findError) { console.error(findError); return fail("Не удалось найти аккаунт.", 500); }
 if (user && user.role !== "client") return fail("Для этого аккаунта предусмотрен отдельный вход.", 403);
 if (!user) {
  const metadata = authUser.user_metadata ?? {};
  const displayName = textOf(metadata.full_name ?? metadata.name ?? metadata.preferred_username ?? email.split("@")[0], 80).slice(0,80) || "Клиент";
  const salt = randomHex(16), generatedPasswordHash = await passwordHash(randomHex(48), salt);
  const { data: created, error: createError } = await db.from("nail_users").insert({ id: crypto.randomUUID(), name: displayName, email, role: "client", password_hash: generatedPasswordHash, password_salt: salt, created_at: new Date().toISOString() }).select("id,name,email,role").single();
  user = created;
  if (createError) {
   const retry = await db.from("nail_users").select("id,name,email,role").eq("email", email).maybeSingle();
   if (retry.error || !retry.data) { console.error(createError, retry.error); return fail("Не удалось создать аккаунт через провайдера.", 500); }
   user = retry.data;
  }
 }
 const token = await createSession(user.id);
 return json({ user: { id: user.id, name: user.name, email: user.email, role: "client" } }, 200, { "set-cookie": sessionCookie(token) });
}
async function register(data: Record<string, unknown>) {
 const name=textOf(data.name,80),email=emailOf(data.email),password=textOf(data.password,256);
 if(name.length<2)return fail("Укажите имя, чтобы мастер знала, как к вам обращаться.");
 if(!validEmail(email))return fail("Проверьте адрес электронной почты.");
 if(email===MASTER_EMAIL)return fail("Для этой почты предусмотрен отдельный вход мастера.");
 if(password.length<8)return fail("Пароль должен содержать не менее 8 символов.");
 const {data:old,error:findError}=await db.from("nail_users").select("id").eq("email",email).maybeSingle();
 if(findError){console.error(findError);return fail("Не удалось создать аккаунт. Попробуйте позже.",500);}
 if(old)return fail("Аккаунт с такой почтой уже есть. Переключись на вход.",409,"EMAIL_EXISTS");
 const id=crypto.randomUUID(),salt=randomHex(16),hash=await passwordHash(password,salt);
 const {error:insertError}=await db.from("nail_users").insert({id,name,email,password_hash:hash,password_salt:salt,role:"client",created_at:new Date().toISOString()});
 if(insertError){console.error(insertError);if(insertError.code==="23505")return fail("Аккаунт с такой почтой уже есть. Переключись на вход.",409,"EMAIL_EXISTS");return fail("Не удалось создать аккаунт. Попробуйте ещё раз.",500);}
 try{const token=await createSession(id);return json({user:{id,name,email,role:"client"}},201,{"set-cookie":sessionCookie(token)});}catch(error){await db.from("nail_users").delete().eq("id",id);console.error(error);return fail("Не удалось завершить регистрацию. Попробуйте ещё раз.",500);}
}
async function createTicket(request:Request,data:Record<string,unknown>){
 const user=await currentUser(request);if(!user)return fail("Войди в аккаунт, чтобы отправить заявку.",401,"AUTH_REQUIRED");
 const service=textOf(data.service,100),date=textOf(data.date,10),time=textOf(data.time,40)||"Неважно",subject=textOf(data.subject,120)||"Запись на маникюр",message=textOf(data.message,1500);
 if(!SERVICES.has(service))return fail("Выбери услугу из списка.");
 if(!/^\d{4}-\d{2}-\d{2}$/.test(date)||date<new Date().toISOString().slice(0,10))return fail("Выбери сегодняшнюю или будущую дату.");
 const now=new Date().toISOString(),ticketId="NAIL-"+crypto.randomUUID().slice(0,8).toUpperCase();
 const {error:te}=await db.from("nail_tickets").insert({id:ticketId,user_id:user.id,service,appointment_date:date,preferred_time:time,subject,status:"pending",created_at:now,updated_at:now});
 if(te){console.error(te);return fail("Не удалось сохранить заявку. Попробуйте ещё раз.",500);}
 const {error:me}=await db.from("nail_messages").insert({id:crypto.randomUUID(),ticket_id:ticketId,sender_id:user.id,sender_role:user.role,body:message||("Здравствуйте! Хочу записаться на "+service.toLowerCase()+"."),read_by_client:user.role==="client",read_by_master:user.role==="master",created_at:now});
 if(me){await db.from("nail_tickets").delete().eq("id",ticketId);console.error(me);return fail("Не удалось сохранить сообщение к заявке.",500);}
 return json({user,ticketId},201);
}
async function tickets(request: Request) {
 const user = await currentUser(request); if (!user) return fail("Войдите, чтобы открыть записи.", 401);
 let q = db.from("nail_tickets").select("*"); if (user.role !== "master") q = q.eq("user_id", user.id);
 const { data: rows, error } = await q.order("updated_at", { ascending: false });
 if (error) { console.error(error); return fail("Не удалось загрузить записи.", 500); }
 const list = rows ?? [];
 if (user.role === "master") list.sort((a,b) => ((a.status === "pending" ? 0 : a.status === "answered" ? 1 : 2) - (b.status === "pending" ? 0 : b.status === "answered" ? 1 : 2)) || String(b.updated_at).localeCompare(String(a.updated_at)));
 const ids = list.map((t) => t.id); let messages: Array<Record<string, unknown>> = []; let owners: Array<Record<string, unknown>> = [];
 if (ids.length) {
  const [mr, ur] = await Promise.all([
   db.from("nail_messages").select("*").in("ticket_id", ids).order("created_at", { ascending: true }),
   db.from("nail_users").select("id,name,email").in("id", [...new Set(list.map((t) => t.user_id))]),
  ]);
  if (mr.error || ur.error) { console.error(mr.error ?? ur.error); return fail("Не удалось загрузить переписку.", 500); }
  messages = mr.data ?? []; owners = ur.data ?? [];
 }
 const byOwner = new Map(owners.map((o) => [String(o.id), o])); const selected = new URL(request.url).searchParams.get("selected");
 const result = list.map((t) => {
  const thread = messages.filter((m) => m.ticket_id === t.id); const readKey = user.role === "master" ? "read_by_master" : "read_by_client";
  const unread = thread.filter((m) => m.sender_role !== user.role && !Boolean(m[readKey])).length; const owner = byOwner.get(String(t.user_id));
  return { ...t, user_name: owner?.name ?? "", user_email: owner?.email ?? "", unread: String(t.id) === selected ? 0 : unread, messages: thread };
 });
 if (selected && list.some((t) => String(t.id) === selected)) {
  const column = user.role === "master" ? "read_by_master" : "read_by_client", sender = user.role === "master" ? "client" : "master";
  const { error: readError } = await db.from("nail_messages").update({ [column]: true }).eq("ticket_id", selected).eq("sender_role", sender); if (readError) console.error(readError);
 }
 return json({ user, tickets: result });
}
async function post(request: Request) {
 const data = await bodyOf(request), action = textOf(data.action, 40);
 if (action === "register") return register(data);
 if (action === "create_ticket") return createTicket(request, data);
 if (action === "login") return login(data);
 if (action === "oauth_login") return oauthLogin(data);
 if (action === "logout") {
  const token = cookieToken(request); if (token) { const { error } = await db.from("nail_sessions").delete().eq("token_hash", await sha256(token)); if (error) console.error(error); }
  return json({ ok: true }, 200, { "set-cookie": sessionCookie("", 0) });
 }
 const user = await currentUser(request); if (!user) return fail("Сначала войдите в аккаунт.", 401);
 if (action === "reply") {
  const ticketId = textOf(data.ticketId, 80), message = textOf(data.message, 1500); if (!ticketId || !message) return fail("Напишите сообщение.");
  const { data: ticket, error } = await db.from("nail_tickets").select("id,user_id,status").eq("id", ticketId).maybeSingle();
  if (error) return fail("Не удалось загрузить запись.", 500);
  if (!ticket || (user.role !== "master" && ticket.user_id !== user.id)) return fail("Тикет не найден.", 404);
  const now = new Date().toISOString(), next = user.role === "master" ? ((ticket.status === "pending" || ticket.status === "answered") ? "answered" : ticket.status) : (ticket.status === "answered" ? "pending" : ticket.status);
  const { error: msgError } = await db.from("nail_messages").insert({ id: crypto.randomUUID(), ticket_id: ticketId, sender_id: user.id, sender_role: user.role, body: message, read_by_client: user.role === "client", read_by_master: user.role === "master", created_at: now });
  if (msgError) { console.error(msgError); return fail("Не удалось отправить сообщение.", 500); }
  const { error: upError } = await db.from("nail_tickets").update({ status: next, updated_at: now }).eq("id", ticketId);
  if (upError) { console.error(upError); return fail("Сообщение сохранено, но статус обновить не удалось.", 500); }
  return json({ ok: true });
 }
 if (action === "status") {
  if (user.role !== "master") return fail("Недостаточно прав.", 403);
  const ticketId = textOf(data.ticketId, 80), status = textOf(data.status, 20); if (!STATUSES.has(status)) return fail("Неизвестный статус.");
  const { error } = await db.from("nail_tickets").update({ status, updated_at: new Date().toISOString() }).eq("id", ticketId);
  if (error) { console.error(error); return fail("Не удалось обновить статус.", 500); } return json({ ok: true });
 }
 return fail("Неизвестное действие.", 404);
}
Deno.serve(async (request: Request) => {
 if (request.method === "OPTIONS") return new Response(null, { status: 204 });
 try {
  if (request.method === "GET") {
   const action = new URL(request.url).searchParams.get("action") ?? "me";
   if (action === "me") return json({ user: await currentUser(request) });
   if (action === "tickets") return tickets(request);
   return fail("Неизвестный запрос.", 404);
  }
  if (request.method === "POST") return await post(request);
  return fail("Метод не поддерживается.", 405);
 } catch (error) { console.error("manicure API failed", error); return fail("Внутренняя ошибка. Попробуйте ещё раз.", 500); }
});
